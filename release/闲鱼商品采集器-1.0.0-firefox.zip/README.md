# 闲鱼商品采集器（Chrome/Edge/Firefox 扩展）

采集闲鱼搜索结果的商品链接与详情，支持并发抓取、实时进度、筛选/排序、多格式导出（CSV / HTML / Excel）。

- 采集能力
  - 列表采集：支持多页滚动与分页跳转、抗风控随机延迟与滚动
  - 详情采集：并发抓取，日志与进度实时更新
- 导出能力
  - CSV：原始文本
  - HTML（美化版）：表头吸顶；顶部筛选（想要数/浏览量/价格 区间）；图片点按放大（Lightbox）；文案默认两行，点击“查看”弹出全文；支持按“想要数/浏览量”升序/降序排序
  - Excel（.xlsx 优先）：封面图片锚定到 B 列对应单元格（100×100），不会越界；若环境不支持自动回退为 .xls（严格模式，固定行高/列宽，限制图片不超格）
- UI
  - 弹窗（popup）：优化表单、按钮与进度条样式，日志清晰可读
- 仅用于学习与研究，请遵守网站条款与法律法规

## 安装（本地调试）
1. 下载或克隆本项目
2. Chrome/Edge 打开 chrome://extensions，开启“开发者模式”
3. “加载已解压的扩展程序”，选择本项目目录（包含 manifest.json）

Firefox（Nightly/Dev/109+）可加载 MV3 临时扩展：打开 about:debugging -> This Firefox -> Load Temporary Add-on... -> 选择 manifest.json 所在目录。

## 使用
1. 打开闲鱼搜索页，输入关键词与页数，并设置并发数、是否采集详情、导出格式
2. 点击“开始采集”
3. 观察日志与进度；完成后自动下载导出文件
4. HTML 导出：
   - 表头吸顶；顶部筛选“想要数/浏览量/价格”
   - 点击图片可放大；文案默认两行，点击“查看”弹出完整内容
   - 可点击按钮按“想要数/浏览量”升序/降序排序

## 多浏览器打包（一键出包）
本项目提供 PowerShell 脚本打包工具，输出 Chrome/Edge/Firefox 三个压缩包。

- 前置：建议使用 PowerShell 7（已内置在本项目说明环境）
- 命令：
  - Windows（PowerShell 7）：
    - 方式一：右键在项目根目录打开 PowerShell，执行
      ```powershell
      .\scripts\build.ps1
      ```
    - 方式二：指定版本号
      ```powershell
      .\scripts\build.ps1 -Version 1.0.1
      ```
- 输出：
  - dist/ 下包含三套打包目录：chrome、edge、firefox
  - release/ 下生成 3 个 zip 包，命名规则：{name}-{version}-{target}.zip
  - Firefox 包会自动在 manifest.json 注入 browser_specific_settings.gecko（含 id 与 strict_min_version=109.0）
  - 若使用了 host_permissions，会合并到 permissions 以提升兼容性

注意：
- Firefox 如需长期安装或上架 AMO，需将 gecko.id 替换成你自己的 ID（脚本默认 xianyucollector@example.com）
- Edge 直接使用 Chrome 包即可安装；也可使用脚本生成的 edge 包

## 权限说明（示例）
- tabs、scripting：脚本注入与标签页交互
- activeTab：当前页采集
- host_permissions：goofish/idle.fish 及图片 CDN 域名
- storage：持久化设置（如需要）

## 开发说明
- content.js：页面采集与导出逻辑（含 HTML/Excel 导出）
- background.js：详情抓取与消息路由
- popup.*：弹窗 UI 与交互
- styles.css：弹窗样式
- xlsx-lite.js：最小化 .xlsx 生成（图片锚定到单元格）
- scripts/build.ps1：打包工具

## 常见问题
- “Receiving end does not exist”：通常为内容脚本未注入（语法错误或域不匹配）。请在目标页 F12 Console 查看是否有 SyntaxError，修复后刷新重试。
- Excel 图片超出单元格：优先使用 .xlsx 导出；如回退 .xls 将固定行高/列宽限制溢出。

## 许可
MIT